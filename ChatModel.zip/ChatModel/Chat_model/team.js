
 function openNav(){
    document.getElementById("sideNav").style.width ="250px";
}
function closeNav(){
    document.getElementById("sideNav").style.width="0";
}

function start(){
    console.log("hello");
        let res_msg =document.createElement('div');
        res_msg.innerHTML ="Hello Iam AI, How can i help you?";
        res_msg.setAttribute('class','left');

        document.getElementsById('chatBot').appendChild(res_msg);
}

document.getElementById('send').addEventListener("click",async(e)=>{
            e.preventDefault();
            var req = document.getElementById('textInput').value ;
            if(req == undefined || res==''){
                console.log("No response...");
            }
            else{
                let res ="";
                const options = {
                    method: 'GET',
                    url: 'https://acobot-brainshop-ai-v1.p.rapidapi.com/get',
                    params: {bid: '178', key: 'sX5A2PcYZbsN5EY6', uid: 'mashape', msg: 'Hello!'},
                    headers: {
                      'x-rapidapi-key': 'b5d1e34b32msh742bdbe82c02994p17b48fjsne59da697f722',
                      'x-rapidapi-host': 'acobot-brainshop-ai-v1.p.rapidapi.com'
                    }
                  };
                  await axios.get(options).then(data=>{
                      res = JSON.stringify(data.data.response)
                  })

                  let msg_req = document.createElement('div');
                  let msg_res = document.createElement('div');

                  let Con1 = document.createElement('div')
                  let Con2 = document.createTextNode('div');

                  msg_req.innerHTML = req;
                  msg_res.innerHTML = res;
                  msg_req.setAttribute(Con1);
                  msg_res.setAttribute(Con2);

                  let message = document.getElementById('chatBot');
                  message.appendChild(Con1);
                  message.appendChild(Con2);

                  Con1.appendChild(msg_req);
                  Con2.appendChild(msg_res);

                  document.getElementById('textInput').value ="";

            }



})
    
      
      



