var unirest = require("unirest");

var req = unirest("GET", "https://acobot-brainshop-ai-v1.p.rapidapi.com/get");

req.query({
	"bid": "178",
	"key": "sX5A2PcYZbsN5EY6",
	"uid": "mashape",
	"msg": "Hello!"
});

req.headers({
	"x-rapidapi-key": "b5d1e34b32msh742bdbe82c02994p17b48fjsne59da697f722",
	"x-rapidapi-host": "acobot-brainshop-ai-v1.p.rapidapi.com",
	"useQueryString": true
});


req.end(function (res) {
	if (res.error) throw new Error(res.error);

	console.log(res.body);
});